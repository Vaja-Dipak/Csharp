﻿using System;

namespace _12345_For_Loop
{
    class Program
    {
        public static void Main(string[] args)
        {
            int i;

            for (i = 1; i <= 5; i++)
            {
                Console.Write("{0} ", i);
            }
            Console.Write("\n\n");
            Console.ReadLine();
        }
    }
}