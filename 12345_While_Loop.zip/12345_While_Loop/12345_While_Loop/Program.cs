﻿using System;

namespace _12345_While_Loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            while (i <= 5)
            {
                Console.Write(i);
                i++;
            }
            Console.ReadLine();
        }
    }
}
