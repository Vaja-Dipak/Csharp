﻿using System;

namespace Operator
{
    class Program
    {
        static void Main(string[] args)
        {
            int c;

            Console.WriteLine("Enter A :");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter B :");
            int b = Convert.ToInt32(Console.ReadLine());

            // Arithmatic Operator
            c = a + b;
            Console.WriteLine("sum of A and B is : " + c);
            c = a - b;
            Console.WriteLine("sub of A and B is : " + c);
            c = a * b;
            Console.WriteLine("mul of A and B is : " + c);
            c = a / b;
            Console.WriteLine("div of A and B is : " + c);
            c = a % b;
            Console.WriteLine("mod of A and B is : " + c + "\n");

            // Relational Operator
            if (a == b)
            {
                Console.WriteLine("A is equel to B");
            }
            if (a < b)
            {
                Console.WriteLine("A is less than B");
            }
            if (a > b)
            {
                Console.WriteLine("A is greater than B");
            }
            if (a <= b)
            {
                Console.WriteLine("A is less than or equal to B");
            }
            if (a >= b)
            {
                Console.WriteLine("A is greater than or equel to B");
            }
            if (a != b)
            {
                Console.WriteLine("A is not equel to B \n");
            }

            // Logical Operator
            bool m = true, n = false, res;
            res = m && n;
            Console.WriteLine("AND Operator: " + res);
            res = m || n;
            Console.WriteLine("OR Operator: " + res);
            res = !m;
            Console.WriteLine("NOT Operator: " + res);
        }
    }
}
