﻿using System;

namespace _12345_dowhile_Loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            do
            {
                Console.Write(i);
                i++;
            }
            while (i <= 5);
            Console.ReadLine();
        }
    }
}
