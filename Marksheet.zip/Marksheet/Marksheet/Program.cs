﻿using System;

namespace Marksheet
{   class Program
    {   static void Main(string[] args)
        {   int r, m1, m2, m3, total;
            float percentage;
            string n;

            Console.WriteLine("Enter Student Roll Number :");
            r = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Student Name :");
            n = Console.ReadLine();
            Console.WriteLine("Enter Marks1, Marks2, Marks3 : ");
            m1 = Convert.ToInt32(Console.ReadLine());
            m2 = Convert.ToInt32(Console.ReadLine());
            m3 = Convert.ToInt32(Console.ReadLine());

            total = m1 + m2 + m3;
            percentage = total / 3.0f;

            Console.WriteLine("Result of " + n);
            Console.WriteLine("Total Marks : " + total);
            Console.WriteLine("Percentage : " + percentage);

            if (percentage < 40)
            { Console.WriteLine("Grade is E"); }
            else if (percentage >= 40 && percentage <= 59)
            { Console.WriteLine("Grade is D"); }
            else if (percentage >= 60 && percentage <= 79)
            { Console.WriteLine("Grade is C"); }
            else if (percentage >= 80 && percentage <= 89)
            { Console.WriteLine("Grade is B"); }
            else if (percentage >= 91)
            { Console.WriteLine("Grade is A"); }
            Console.ReadLine();
        }
    }
}
