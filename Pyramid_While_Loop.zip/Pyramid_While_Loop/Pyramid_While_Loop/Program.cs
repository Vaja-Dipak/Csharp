﻿using System;

namespace Pyramid_While_Loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            while (i <= 5)
            {
                int j = 1;
                while (j <= i)
                {
                    Console.Write(j + " ");
                    j++;
                }
                i++;
                Console.WriteLine();
            }
            Console.Read();
        }
    }
}
