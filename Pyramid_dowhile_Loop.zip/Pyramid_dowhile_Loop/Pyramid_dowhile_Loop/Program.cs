﻿using System;

namespace Pyramid_dowhile_Loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            do
            {
                int j = 1;
                do
                {
                    Console.Write(j + " ");
                    j++;
                }
                while (j <= i);
                Console.WriteLine();
                i++;
            }
            while (i <= 5);
            Console.Read();
        }
    }
}
